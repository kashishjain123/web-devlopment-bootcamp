# weather
## Sample Project Showing API calls
## Using [Open Weather API](https://openweathermap.org/)
